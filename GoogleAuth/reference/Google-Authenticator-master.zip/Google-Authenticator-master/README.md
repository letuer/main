## Java 接入 Google Authenticator
详情请看简书博客[Java 接入 Google Authenticator](http://www.jianshu.com/p/de903c074d77)
